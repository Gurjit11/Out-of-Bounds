import React from 'react'

const Drafts = () => {
  return (
    <div>Drafts</div>
  )
}

export default Drafts