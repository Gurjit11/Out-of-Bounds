import React from 'react'
// import { IoClose } from "react-icons/io5";
// import { IoMenu } from "react-icons/io5";
import { FaHome, FaPlusCircle , FaUserCircle} from "react-icons/fa";
import bloglogo from './outofboundslogo.png';


function Navbar() {
    
  return (
    <div>
      <nav className="p-5 bg-black shadow md:flex md:items-center md:justify-between">
    <div className="flex justify-between items-center ml-3 ">
      <span className="text-2xl font-[Poppins] text-white cursor-pointer block">
        <img className="h-10 inline rounded-full" src={bloglogo} alt="logo"/>
        
      </span>
    <h5 className='text-white ml-4 text-2xl'>BlogEarth</h5>
    </div>

    <ul className="md:flex md:items-center md:z-auto text-white bg-black left-0 md:w-auto md:py-0 py-4 md:pl-0 pl-7 md:opacity-100">
      <li className="mx-4 my-6 md:my-0">
        <a href="/" className="text-2xl active hover:text-cyan-500 duration-500"><FaHome/></a>
      </li>
      <li className="mx-4 my-6 md:my-0">
        <a href="/" className="text-2xl hover:text-cyan-500 duration-500"><FaUserCircle/></a>
      </li>
      <li className="mx-4 my-6 md:my-0">
        <a href="/" className="text-2xl hover:text-cyan-500 duration-500"><FaPlusCircle/></a>
      </li>
      <button className="bg-gradient-to-r from-green-400 to-blue-400 text-white text-bold font-[Poppins] duration-500 px-6 py-2 mx-4 hover:from-red-400 hover:to-yellow-400 text-white rounded ">
        Sign Up
      </button>
      <button className="bg-gradient-to-r from-green-400 to-blue-400 text-white text-bold font-[Poppins] duration-500 px-6 py-2 mr-4 hover:from-red-400 hover:to-yellow-400 text-white  rounded ">
        Log In
      </button>

    </ul>
  </nav>
    </div>
  )
}

export default Navbar
