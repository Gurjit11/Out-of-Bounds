import React from 'react'

const Blogcard = () => {
  return (
    <div>Blogcard</div>
  )
}

export default Blogcard