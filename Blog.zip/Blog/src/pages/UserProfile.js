import React from 'react'
import Navbar from '../Components/Navbar'

const UserProfile = () => {
  return (
    <div>
      <Navbar/>
    <div>
      
      UserProfile
    </div>
    </div>
  )
}

export default UserProfile