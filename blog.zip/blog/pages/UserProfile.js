import React from 'react'

const UserProfile = () => {
  return (
    <div>UserProfile</div>
  )
}

export default UserProfile