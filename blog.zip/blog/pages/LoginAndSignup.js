import React from 'react'

const LoginAndSignup = () => {
  return (
    <div>LoginAndSignup</div>
  )
}

export default LoginAndSignup