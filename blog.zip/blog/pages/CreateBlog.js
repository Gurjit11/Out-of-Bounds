import React from 'react'

const CreateBlog = () => {
  return (
    <div>CreateBlog</div>
  )
}

export default CreateBlog