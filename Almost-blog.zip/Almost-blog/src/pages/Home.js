import React from 'react'
import Blogcard from '../Components/Blogcard'
import Navbar from '../Components/Navbar'

const Home = () => {
  return (
    <div >
      {/* <Navbar/> */}
      <Blogcard/>
    </div>
  )
}

export default Home